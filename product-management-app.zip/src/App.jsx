
import { useEffect, useState } from "react";

const PAGE_SIZE = 5;

export default function App() {
  const [products, setProducts] = useState([]);
  const [view, setView] = useState("list");
  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [page, setPage] = useState(1);
  const [editing, setEditing] = useState(null);

  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearch(search);
      setPage(1);
    }, 500);
    return () => clearTimeout(timer);
  }, [search]);

  const filtered = products.filter(p =>
    p.name.toLowerCase().includes(debouncedSearch.toLowerCase())
  );

  const totalPages = Math.ceil(filtered.length / PAGE_SIZE);
  const paginated = filtered.slice(
    (page - 1) * PAGE_SIZE,
    page * PAGE_SIZE
  );

  const handleSave = (product) => {
    if (editing) {
      setProducts(products.map(p => p.id === product.id ? product : p));
    } else {
      setProducts([...products, { ...product, id: Date.now() }]);
    }
    setEditing(null);
  };

  return (
    <div className="container">
      <h2>Product Management</h2>

      <div className="top-bar">
        <input
          placeholder="Search product..."
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
        <button onClick={() => setView(view === "list" ? "card" : "list")}>
          Switch to {view === "list" ? "Card" : "List"} View
        </button>
      </div>

      <ProductForm onSave={handleSave} editing={editing} />

      {view === "list" ? (
        <table>
          <thead>
            <tr>
              <th>Name</th><th>Price</th><th>Category</th><th>Stock</th><th>Action</th>
            </tr>
          </thead>
          <tbody>
            {paginated.map(p => (
              <tr key={p.id}>
                <td>{p.name}</td>
                <td>{p.price}</td>
                <td>{p.category}</td>
                <td>{p.stock}</td>
                <td>
                  <button onClick={() => setEditing(p)}>Edit</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <div className="grid">
          {paginated.map(p => (
            <div className="card" key={p.id}>
              <h4>{p.name}</h4>
              <p>₹{p.price}</p>
              <p>{p.category}</p>
              <button onClick={() => setEditing(p)}>Edit</button>
            </div>
          ))}
        </div>
      )}

      <div className="pagination">
        <button disabled={page === 1} onClick={() => setPage(page - 1)}>Prev</button>
        <span>{page} / {totalPages || 1}</span>
        <button disabled={page === totalPages} onClick={() => setPage(page + 1)}>Next</button>
      </div>
    </div>
  );
}

function ProductForm({ onSave, editing }) {
  const [form, setForm] = useState({
    name: "", price: "", category: "", stock: "", description: ""
  });
  const [errors, setErrors] = useState({});

  useEffect(() => {
    if (editing) setForm(editing);
  }, [editing]);

  const validate = () => {
    let e = {};
    if (!form.name) e.name = "Required";
    if (!form.price) e.price = "Required";
    if (!form.category) e.category = "Required";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const submit = () => {
    if (!validate()) return;
    onSave(form);
    setForm({ name: "", price: "", category: "", stock: "", description: "" });
  };

  return (
    <div className="form">
      <h3>{editing ? "Edit Product" : "Add Product"}</h3>
      <input placeholder="Name" value={form.name}
        onChange={e => setForm({ ...form, name: e.target.value })} />
      {errors.name && <span>{errors.name}</span>}

      <input type="number" placeholder="Price" value={form.price}
        onChange={e => setForm({ ...form, price: e.target.value })} />
      {errors.price && <span>{errors.price}</span>}

      <input placeholder="Category" value={form.category}
        onChange={e => setForm({ ...form, category: e.target.value })} />
      {errors.category && <span>{errors.category}</span>}

      <input type="number" placeholder="Stock" value={form.stock}
        onChange={e => setForm({ ...form, stock: e.target.value })} />

      <textarea placeholder="Description"
        value={form.description}
        onChange={e => setForm({ ...form, description: e.target.value })} />

      <button onClick={submit}>Save</button>
    </div>
  );
}
